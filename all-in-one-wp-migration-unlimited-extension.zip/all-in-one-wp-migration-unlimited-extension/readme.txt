=== Unlimited Backup Plugin ===
Contributors: Stingray82
Tags: All-in-one-migration, backup, unlimited
Requires at least: 6.5
Tested up to: 6.8.2
Stable tag: 2.73.2
Requires PHP: 8.0
License: GPL-3.0-or-later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

An addon to allow unlimited file size for all-in-one-migration plugin
== Description ==
Install on your dashboard and it will enable unlimited backup
== Installation ==
1. Upload the `unlimited-backup-ai1wmue` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==
= Why was this plugin created? =
This plugin is a fork of the Unlimited extension by all-in-one-migration after they changed there EULA policy and cancelled my licence I decided to fork and update and merge there changes moving forward into this extension, you can read more about it here
https://techarticles.co.uk/software-freedom-the-gpl-and-our-experience-with-servmask/
= Can anyone do this? =
The plugin is GPL and the GPL licence allows you to do this, if you want to make your own fork this plugin and knock yourself out
= So no updates? =
I plan on pushing updates to this moving forward based on the development of the original plugin and its addon, updates will be served automatically using another of my projects UUPD just like any other WordPress plugin
= Can I contribute? =
Yes please do, create a pull request and after testing we can then merge it
 
== Changelog == 
= 2.73.2 12 August 2025 = 
Corrected License Issue for GPL Software V3.0 - in readme updated automation

= 2.73.1 12 August 2025 = 
Corrected License Issue for GPL Software V3.0

= 2.73 20 July 2025 =
Update to Native 2.73 - ServMask Removed EULA

